import { TestBed } from '@angular/core/testing';

import { ReglesMetiersService } from './regles-metiers.service';

describe('ReglesMetiersService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReglesMetiersService = TestBed.get(ReglesMetiersService);
    expect(service).toBeTruthy();
  });
});
