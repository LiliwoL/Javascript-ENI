import { TestBed } from '@angular/core/testing';

import { GestionsDatasService } from './gestions-datas.service';

describe('GestionsDatasService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GestionsDatasService = TestBed.get(GestionsDatasService);
    expect(service).toBeTruthy();
  });
});
