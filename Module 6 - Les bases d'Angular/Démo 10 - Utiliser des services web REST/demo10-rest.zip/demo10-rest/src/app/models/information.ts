export class Information {
  public uuid: string;
  constructor(public evenement: string, public auteur: string) {}
}
