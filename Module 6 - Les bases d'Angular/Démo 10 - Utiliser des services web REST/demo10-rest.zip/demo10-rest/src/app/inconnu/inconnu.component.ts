import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inconnu',
  templateUrl: './inconnu.component.html',
  styleUrls: ['./inconnu.component.css']
})
export class InconnuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
