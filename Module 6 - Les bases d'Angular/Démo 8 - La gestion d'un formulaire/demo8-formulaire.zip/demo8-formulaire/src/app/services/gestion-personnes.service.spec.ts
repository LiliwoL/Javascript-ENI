import { TestBed } from '@angular/core/testing';

import { GestionPersonnesService } from './gestion-personnes.service';

describe('GestionPersonnesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GestionPersonnesService = TestBed.get(GestionPersonnesService);
    expect(service).toBeTruthy();
  });
});
