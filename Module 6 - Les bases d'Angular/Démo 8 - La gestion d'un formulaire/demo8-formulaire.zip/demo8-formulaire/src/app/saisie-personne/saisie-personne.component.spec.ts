import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaisiePersonneComponent } from './saisie-personne.component';

describe('SaisiePersonneComponent', () => {
  let component: SaisiePersonneComponent;
  let fixture: ComponentFixture<SaisiePersonneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaisiePersonneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaisiePersonneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
